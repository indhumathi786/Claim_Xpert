package com.java.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.webkit.MimeTypeMap;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ClaimFormActivity extends AppCompatActivity {

    private static final String TAG = "ClaimFormActivity";
    private TextView textViewPolicyNumber;
    private TextView textViewPolicyHolderName;
    private EditText editTextHospitalName;
    private EditText editTextDateOfAdmission;
    private EditText editTextReasonForAdmission;
    private Button buttonUploadHospitalBill;
    private TextView textViewHospitalBillStatus;
    private Button buttonUploadDischargeSummary;
    private TextView textViewDischargeSummaryStatus;
    private Button buttonSubmitClaim;

    private Uri hospitalBillUri;
    private Uri dischargeSummaryUri;
    private String policyNumber;
    private String policyHolderName;

    private static final int PICK_HOSPITAL_BILL_REQUEST = 1;
    private static final int PICK_DISCHARGE_SUMMARY_REQUEST = 2;
    private static final long MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_claim_form);

        initializeViews();
        setupPreFilledData();
        setupClickListeners();
    }

    private void initializeViews() {
        textViewPolicyNumber = findViewById(R.id.textViewPolicyNumber);
        textViewPolicyHolderName = findViewById(R.id.textViewPolicyHolderName);
        editTextHospitalName = findViewById(R.id.editTextHospitalName);
        editTextDateOfAdmission = findViewById(R.id.editTextDateOfAdmission);
        editTextReasonForAdmission = findViewById(R.id.editTextReasonForAdmission);
        buttonUploadHospitalBill = findViewById(R.id.buttonUploadHospitalBill);
        textViewHospitalBillStatus = findViewById(R.id.textViewHospitalBillStatus);
        buttonUploadDischargeSummary = findViewById(R.id.buttonUploadDischargeSummary);
        textViewDischargeSummaryStatus = findViewById(R.id.textViewDischargeSummaryStatus);
        buttonSubmitClaim = findViewById(R.id.buttonSubmitClaim);
    }

    private void setupPreFilledData() {
        policyNumber = getIntent().getStringExtra("policyNumber");
        policyHolderName = getIntent().getStringExtra("policyHolderName");

        textViewPolicyNumber.setText("Policy Number: " + policyNumber);
        textViewPolicyHolderName.setText("Policy Holder Name: " + policyHolderName);
    }

    private void setupClickListeners() {
        buttonUploadHospitalBill.setOnClickListener(v -> openFileChooser(PICK_HOSPITAL_BILL_REQUEST));
        buttonUploadDischargeSummary.setOnClickListener(v -> openFileChooser(PICK_DISCHARGE_SUMMARY_REQUEST));
        buttonSubmitClaim.setOnClickListener(v -> validateAndSubmitClaim());
    }

    private void openFileChooser(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("application/pdf,image/*"); // Allow only PDFs and images
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(Intent.createChooser(intent, "Select File"), requestCode);
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(this, "Please install a File Manager.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri selectedFileUri = data.getData();
            if (validateFile(selectedFileUri)) {
                if (requestCode == PICK_HOSPITAL_BILL_REQUEST) {
                    hospitalBillUri = selectedFileUri;
                    textViewHospitalBillStatus.setText("Hospital Bill Selected ✓");
                    textViewHospitalBillStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
                } else if (requestCode == PICK_DISCHARGE_SUMMARY_REQUEST) {
                    dischargeSummaryUri = selectedFileUri;
                    textViewDischargeSummaryStatus.setText("Discharge Summary Selected ✓");
                    textViewDischargeSummaryStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
                }
            }
        }
    }

    private boolean validateFile(Uri fileUri) {
        try {
            String mimeType = getContentResolver().getType(fileUri);
            if (mimeType == null) {
                Toast.makeText(this, "Invalid file type", Toast.LENGTH_SHORT).show();
                return false;
            }

            // Check file type
            if (!mimeType.startsWith("image/") && !mimeType.equals("application/pdf")) {
                Toast.makeText(this, "Please upload only PDF or image files", Toast.LENGTH_SHORT).show();
                return false;
            }

            // Check file size
            long fileSize = getContentResolver().openFileDescriptor(fileUri, "r").getStatSize();
            if (fileSize > MAX_FILE_SIZE) {
                Toast.makeText(this, "File size should be less than 5MB", Toast.LENGTH_SHORT).show();
                return false;
            }

            return true;
        } catch (Exception e) {
            Toast.makeText(this, "Error validating file", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private void validateAndSubmitClaim() {
        String hospitalName = editTextHospitalName.getText().toString().trim();
        String dateOfAdmission = editTextDateOfAdmission.getText().toString().trim();
        String reasonForAdmission = editTextReasonForAdmission.getText().toString().trim();

        if (validateInputs(hospitalName, dateOfAdmission, reasonForAdmission)) {
            try {
                // Generate claim ID
                String claimId = generateClaimId();
                Log.d(TAG, "Generated Claim ID: " + claimId);
                
                // Create intent for preview and tracking
                Intent intent = new Intent(ClaimFormActivity.this, PreviewAndTrackingActivity.class);
                
                // Pass all necessary data
                intent.putExtra("claimId", claimId);
                intent.putExtra("policyNumber", policyNumber);
                intent.putExtra("policyHolderName", policyHolderName);
                intent.putExtra("hospitalName", hospitalName);
                intent.putExtra("dateOfAdmission", dateOfAdmission);
                intent.putExtra("reasonForAdmission", reasonForAdmission);
                intent.putExtra("hospitalBillUri", hospitalBillUri.toString());
                intent.putExtra("dischargeSummaryUri", dischargeSummaryUri.toString());
                
                Log.d(TAG, "Starting PreviewAndTrackingActivity with data: " + 
                      "policyNumber=" + policyNumber + 
                      ", hospitalName=" + hospitalName);
                
                startActivity(intent);
            } catch (Exception e) {
                Log.e(TAG, "Error starting PreviewAndTrackingActivity", e);
                Toast.makeText(this, "Error submitting claim. Please try again.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private boolean validateInputs(String hospitalName, String dateOfAdmission, String reasonForAdmission) {
        if (hospitalName.isEmpty()) {
            editTextHospitalName.setError("Hospital name is required");
            return false;
        }
        if (dateOfAdmission.isEmpty()) {
            editTextDateOfAdmission.setError("Date of admission is required");
            return false;
        }
        if (reasonForAdmission.isEmpty()) {
            editTextReasonForAdmission.setError("Reason for admission is required");
            return false;
        }
        if (hospitalBillUri == null) {
            Toast.makeText(this, "Please upload hospital bill", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (dischargeSummaryUri == null) {
            Toast.makeText(this, "Please upload discharge summary", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private String generateClaimId() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss", Locale.getDefault());
        return "CLM" + sdf.format(new Date());
    }
}