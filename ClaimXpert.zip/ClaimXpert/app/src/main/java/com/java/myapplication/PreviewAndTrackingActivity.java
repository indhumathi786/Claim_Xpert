package com.java.myapplication;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import androidx.appcompat.app.AppCompatActivity;

public class PreviewAndTrackingActivity extends AppCompatActivity {

    private TextView textViewClaimId;
    private TextView textViewPolicyDetails;
    private TextView textViewHospitalDetails;
    private WebView webViewHospitalBill;
    private WebView webViewDischargeSummary;
    private LinearLayout layoutTrackingStatus;
    private ProgressBar progressBarClaim;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preview_and_tracking);

        initializeViews();
        displayClaimDetails();
        setupDocumentPreviews();
        setupTrackingStatus();
    }

    private void initializeViews() {
        textViewClaimId = findViewById(R.id.textViewClaimId);
        textViewPolicyDetails = findViewById(R.id.textViewPolicyDetails);
        textViewHospitalDetails = findViewById(R.id.textViewHospitalDetails);
        webViewHospitalBill = findViewById(R.id.webViewHospitalBill);
        webViewDischargeSummary = findViewById(R.id.webViewDischargeSummary);
        layoutTrackingStatus = findViewById(R.id.layoutTrackingStatus);
        progressBarClaim = findViewById(R.id.progressBarClaim);
    }

    private void displayClaimDetails() {
        String claimId = getIntent().getStringExtra("claimId");
        String policyNumber = getIntent().getStringExtra("policyNumber");
        String policyHolderName = getIntent().getStringExtra("policyHolderName");
        String hospitalName = getIntent().getStringExtra("hospitalName");
        String dateOfAdmission = getIntent().getStringExtra("dateOfAdmission");
        String reasonForAdmission = getIntent().getStringExtra("reasonForAdmission");

        textViewClaimId.setText("Claim ID: " + claimId);
        textViewPolicyDetails.setText(String.format("Policy Details:\nPolicy Number: %s\nPolicy Holder: %s",
                policyNumber, policyHolderName));
        textViewHospitalDetails.setText(String.format("Hospital Details:\nHospital: %s\nDate of Admission: %s\nReason: %s",
                hospitalName, dateOfAdmission, reasonForAdmission));
    }

    private void setupDocumentPreviews() {
        String hospitalBillUriStr = getIntent().getStringExtra("hospitalBillUri");
        String dischargeSummaryUriStr = getIntent().getStringExtra("dischargeSummaryUri");

        if (hospitalBillUriStr != null) {
            Uri hospitalBillUri = Uri.parse(hospitalBillUriStr);
            setupWebView(webViewHospitalBill, hospitalBillUri);
        }

        if (dischargeSummaryUriStr != null) {
            Uri dischargeSummaryUri = Uri.parse(dischargeSummaryUriStr);
            setupWebView(webViewDischargeSummary, dischargeSummaryUri);
        }
    }

    private void setupWebView(WebView webView, Uri documentUri) {
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl(documentUri.toString());
    }

    private void setupTrackingStatus() {
        // Mock tracking status - In a real app, this would be fetched from a backend
        String[] stages = {
            "Claim Submitted",
            "Documents Verified",
            "Under Processing",
            "Approval Pending",
            "Claim Approved"
        };

        int currentStage = 1; // Mock current stage
        
        for (int i = 0; i < stages.length; i++) {
            TextView stageText = new TextView(this);
            stageText.setText(stages[i]);
            stageText.setPadding(20, 10, 20, 10);
            
            if (i <= currentStage) {
                stageText.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
            } else {
                stageText.setTextColor(getResources().getColor(android.R.color.darker_gray));
            }
            
            layoutTrackingStatus.addView(stageText);
        }

        // Update progress bar
        progressBarClaim.setMax(stages.length - 1);
        progressBarClaim.setProgress(currentStage);
    }
} 