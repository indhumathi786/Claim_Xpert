package com.java.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class PolicyFinder extends AppCompatActivity {

    private EditText editTextPolicyNumber;
    private Button buttonFetchPolicy;
    private TextView textViewVerificationStatus;
    private Map<String, Map<String, String>> policyData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_policy_finder);

        editTextPolicyNumber = findViewById(R.id.editTextPolicyNumber);
        buttonFetchPolicy = findViewById(R.id.buttonFetchPolicy);
        textViewVerificationStatus = findViewById(R.id.textViewVerificationStatus);

        // Load policy data from CSV when activity is created
        loadPolicyDataFromCSV();

        buttonFetchPolicy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String policyNumber = editTextPolicyNumber.getText().toString().trim();
                if (!policyNumber.isEmpty()) {
                    verifyUserAndFetchPolicy(policyNumber);
                } else {
                    Toast.makeText(PolicyFinder.this, "Please enter your policy number", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void loadPolicyDataFromCSV() {
        policyData = new HashMap<>();
        try {
            InputStream is = getAssets().open("insurance_dataset.csv");
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String line;
            String[] headers = null;
            
            while ((line = reader.readLine()) != null) {
                String[] values = line.split(",");
                if (headers == null) {
                    headers = values; // First line contains headers
                    continue;
                }
                
                if (values.length >= 5) {  // Ensure we have all required columns
                    Map<String, String> rowData = new HashMap<>();
                    String policyNumber = values[0].trim();
                    for (int i = 0; i < headers.length; i++) {
                        rowData.put(headers[i].trim(), values[i].trim());
                    }
                    policyData.put(policyNumber, rowData);
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error loading policy data", Toast.LENGTH_SHORT).show();
        }
    }

    private void verifyUserAndFetchPolicy(final String policyNumber) {
        textViewVerificationStatus.setVisibility(View.VISIBLE);
        textViewVerificationStatus.setText("Verifying User...");

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                textViewVerificationStatus.setText("Fetching Policy Details...");
                fetchPolicyDetails(policyNumber);
            }
        }, 1500);
    }

    private void fetchPolicyDetails(final String policyNumber) {
        if (policyData.containsKey(policyNumber)) {
            Map<String, String> policy = policyData.get(policyNumber);
            try {
                JSONObject policyJson = new JSONObject();
                for (Map.Entry<String, String> entry : policy.entrySet()) {
                    policyJson.put(entry.getKey(), entry.getValue());
                }
                sendPolicyToDetailsActivity(policyJson);
            } catch (JSONException e) {
                e.printStackTrace();
                showError("Failed to process policy details");
            }
        } else {
            showError("No people insured with that policy number");
        }
    }

    private void sendPolicyToDetailsActivity(final JSONObject policyJson) {
        try {
            final String policyNumber = policyJson.getString("Policy Number");
            final String policyHolderName = policyJson.getString("Policy Holder Name");
            final String insuranceCompanyName = policyJson.getString("Insurance Company");
            final String sumInsured = policyJson.getString("Sum Insured (₹)");
            final String roomRentLimit = policyJson.getString("Room Rent Limit");

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    textViewVerificationStatus.setVisibility(View.GONE);
                    Intent intent = new Intent(PolicyFinder.this, PolicyDetailsActivity.class);
                    intent.putExtra("policyNumber", policyNumber);
                    intent.putExtra("policyHolderName", policyHolderName);
                    intent.putExtra("insuranceCompanyName", insuranceCompanyName);
                    intent.putExtra("sumInsured", sumInsured);
                    intent.putExtra("roomRentLimit", roomRentLimit);
                    startActivity(intent);
                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
            showError("Failed to parse policy details");
        }
    }

    private void showError(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                textViewVerificationStatus.setVisibility(View.GONE);
                Toast.makeText(PolicyFinder.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }
}