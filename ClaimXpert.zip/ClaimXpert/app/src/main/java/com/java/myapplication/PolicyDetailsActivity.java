package com.java.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PolicyDetailsActivity extends AppCompatActivity {

    private TextView textViewPolicyNumber;
    private TextView textViewPolicyHolderName;
    private TextView textViewInsuranceCompany;
    private TextView textViewSumInsured;
    private TextView textViewRoomRentLimit;
    private Button buttonProceedClaim;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_policy_details);

        textViewPolicyNumber = findViewById(R.id.textViewPolicyNumber);
        textViewPolicyHolderName = findViewById(R.id.textViewPolicyHolderName);
        textViewInsuranceCompany = findViewById(R.id.textViewInsuranceCompany);
        textViewSumInsured = findViewById(R.id.textViewSumInsured);
        textViewRoomRentLimit = findViewById(R.id.textViewRoomRentLimit);
        buttonProceedClaim = findViewById(R.id.buttonProceedClaim);

        // Get the policy details passed from the previous activity
        String policyNumber = getIntent().getStringExtra("policyNumber");
        String policyHolderName = getIntent().getStringExtra("policyHolderName");
        String insuranceCompanyName = getIntent().getStringExtra("insuranceCompanyName");
        String sumInsured = getIntent().getStringExtra("sumInsured");
        String roomRentLimit = getIntent().getStringExtra("roomRentLimit");

        // Display the policy details
        textViewPolicyNumber.setText("Policy Number: " + policyNumber);
        textViewPolicyHolderName.setText("Policy Holder Name: " + policyHolderName);
        textViewInsuranceCompany.setText("Insurance Company: " + insuranceCompanyName);
        textViewSumInsured.setText("Sum Insured: " + sumInsured);

        if (roomRentLimit != null && !roomRentLimit.isEmpty()) {
            textViewRoomRentLimit.setText("Room Rent Limit: " + roomRentLimit);
            textViewRoomRentLimit.setVisibility(View.VISIBLE);
        } else {
            textViewRoomRentLimit.setVisibility(View.GONE);
        }

        buttonProceedClaim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the claim form activity
                Intent intent = new Intent(PolicyDetailsActivity.this, ClaimFormActivity.class);
                intent.putExtra("policyNumber", policyNumber);
                intent.putExtra("policyHolderName", policyHolderName);
                startActivity(intent);
            }
        });
    }
}